﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using WPF_MasterDetailApp;
using WPF_MasterDetailApp.Models;

namespace WPF_MasterDetailApp.BusinessLayer
{
    public class ProductBL
    {
        #region ENUMS



        #endregion

        #region FIELDS

        ProductWindowView _productWindowView;
        ProductWindowPresenter _productWindowPresenter;

        #endregion

        #region PROPERTIES

        #endregion

        #region CONSTRUCTORS

        public ProductBL()
        {
            //
            // instantiate the view model and initialize the data set
            //

            _productWindowPresenter = new ProductWindowPresenter(GetCompanyData(), GetProductData());

            //
            // instantiate, set the data context, and show the Main Window
            //
            _productWindowView = new ProductWindowView(_productWindowPresenter);
            _productWindowView.DataContext = _productWindowPresenter;
            _productWindowView.Show();
        }

        #endregion

        #region METHODS

        private Company GetCompanyData()
        {
            return new Company()
            {
                Name = "Tandem Ciders",
                Address = "Tandem Ciders",
                City = "Suttons Bay"
            };
        }

        private Product GetProductData()
        {
            return
                new Product()
                {
                    Id = 1,
                    AppleVariety = "McIntosh",
                    Taste = "Sweet",
                    Color = "Red",
                    Russeting = "None",
                    ImageFileName = "mcintosh.png",
                    Description = "The McIntosh apple is a small- to medium-sized round fruit with a short stem. It has a red and green skin that is thick, tender, and easy to peel. Its white flesh is sometime tinged with green or pink and is juicy, tender, and firm, soon becoming soft. The flesh is easily bruised.",
                    HireDate = DateTime.Parse("01-01-1606"),
                    AverageAnnualGross = 140
                };
        }

        #endregion

        #region EVENTS


        #endregion

    }
}
